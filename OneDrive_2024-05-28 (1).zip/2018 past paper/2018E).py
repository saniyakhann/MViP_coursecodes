# -*- coding: utf-8 -*-
"""
Created on Thu May  2 08:17:03 2024

@author: s2147128
"""

import numpy as np
import matplotlib.pyplot as plt

# Set parameters
N = 30
M = 0.1
a = 0.1
k = 0.1
alpha = 0.0003
dx = 1
dt = 0.01  # Chosen based on stability considerations
total_steps = 5000  # Total number of time steps

# Initialize phi with noise
np.random.seed(0)  # For reproducibility
phi = np.ones((N, N)) + 0.01 * np.random.standard_normal((N, N))  #the second part here adds noise

def laplacian(Z):
    """Compute the Laplacian of the array Z using periodic boundary conditions."""
    return (np.roll(Z, 1, axis=0) + np.roll(Z, -1, axis=0) +
            np.roll(Z, 1, axis=1) + np.roll(Z, -1, axis=1) - 4 * Z)

def update_phi(phi):
    """Update phi using the Cahn-Hilliard equation."""
    mu = a * phi * (phi - 1) * (phi - 2) - k * laplacian(phi)
    new_phi = phi + dt * (M * laplacian(mu) + alpha * phi * (1 - phi))
    return new_phi

# Evolution loop
for _ in range(total_steps):
    phi = update_phi(phi)

# Plot the final state
plt.figure(figsize=(8, 8))
plt.contourf(phi, levels=50, cmap='viridis')
plt.colorbar()
plt.title('Steady State Contour Plot of $\\phi$')
plt.show()

# Save the data to a file
np.savetxt('steady_state_phi.csv', phi, delimiter=',')
