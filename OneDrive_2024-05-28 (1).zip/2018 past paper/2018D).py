# -*- coding: utf-8 -*-
"""
Created on Thu May  2 07:55:44 2024

@author: s2147128
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import linregress

# Set parameters
N = 1000               # Number of lattice sites
D = 1                  # Diffusion coefficient
alpha = 1              # Reaction rate
dt = 0.01              # Time step
dx = 1                 # Spatial discretization
total_time = 50        # Total time for simulation
steps = int(total_time / dt)

# k values from 0.1 to 1 with step 0.1
k_values = np.arange(0.1, 1.1, 0.1)
wave_velocities = []

for k in k_values:
    # Initialize the grid with exponential decay
    phi = np.exp(-k * np.arange(N))

    # For storing the integral of phi over time
    integral_phi = []

    # Update function for each time step
    def update_phi(phi):
        new_phi = phi.copy()
        for x in range(1, N - 1):
            # Central difference approximation for the Laplacian
            laplacian = phi[x - 1] + phi[x + 1] - 2 * phi[x]
            new_phi[x] = phi[x] + dt * (D * laplacian + alpha * phi[x] * (1 - phi[x]))

        # Boundary conditions
        new_phi[0] = 1  # Fixed boundary condition at x=0
        new_phi[N - 1] = new_phi[N - 2]  # No-flux boundary condition at x=N-1
        return new_phi

    # Time evolution
    for _ in range(steps):
        phi = update_phi(phi)
        integral_phi.append(np.sum(phi) * dx)  # Integral of phi over space

    # Linear fit to find the velocity
    time_array = np.linspace(0, total_time, steps)
    slope, _, _, _, _ = linregress(time_array, integral_phi)
    wave_velocities.append(slope)

# Plotting wave velocity vs k
plt.figure(figsize=(8, 5))
plt.plot(k_values, wave_velocities, marker='o', linestyle='-')
plt.xlabel('Decay Rate k')
plt.ylabel('Wave Velocity')
plt.title('Wave Velocity vs Decay Rate')
plt.grid(True)
plt.show()
