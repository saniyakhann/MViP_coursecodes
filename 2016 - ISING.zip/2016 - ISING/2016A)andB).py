# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 13:11:40 2024

@author: s2147128
"""
#2016 paper ISING MODEL example animation code 

#theoretical explaination in paper:
#(i) J large and negative, h = 0
#For J large and negative in an antiferromagnetic Ising model,
#the energetically favorable state is for neighboring spins 
#to be aligned oppositely because the energy contribution from each pair
#−J⋅S i⋅S j will be minimized (i.e., most negative) when 𝑆𝑖 and 𝑆𝑗.
#are of opposite signs. 
#Hence, the system will tend to form a checkerboard pattern.

#Expected values:

#Magnetization (M): The sum of all spins. Given that approximately half the spins will be +1 and half -1 in a large checkerboard pattern, 
#𝑀
#M should be close to zero.
#Staggered Magnetization (Ms): This quantifies the antiferromagnetic order and should have a large magnitude (close to 
#𝑁
#N, the total number of spins), indicating strong antiferromagnetic ordering.

#(ii) J = −1, and h large and positive
#With a strong positive magnetic field ℎh and 𝐽=−1J=−1, the field ℎh 
#will dominate the spin interactions, leading to all spins aligning with the field to minimize the 
#−ℎ∑𝑖𝑆𝑖−h∑ iS i term. 
#Thus, all spins will prefer to be +1 to lower the energy, 
#aligning with the field direction.

#Expected values:

#Magnetization (M): Should be maximized, approximately equal to 𝑁 (all spins aligned positively).
#Staggered Magnetization (Ms): Since 𝑀𝑠 
#incorporates a positional sign change, and all spins are aligned, 
#𝑀𝑠 will be significantly reduced and could approach zero,
#indicating the breakdown of antiferromagnetic order due to the external field.


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Parameters
L = 50  # Lattice size
N = L * L  # Total number of spins
J = -1  # Coupling constant (antiferromagnetic)
k_B = 1  # Boltzmann constant
T = 1  # Temperature (arbitrary units)
h = 0.1  # External magnetic field

# Initialize the lattice randomly
np.random.seed(0)
spin_array = np.random.choice([-1, 1], size=(L, L))

def delta_E(i, j, spin):
    """Calculate the energy change if the spin at (i, j) is flipped."""
    top = spin_array[(i-1) % L, j]
    bottom = spin_array[(i+1) % L, j]
    left = spin_array[i, (j-1) % L]
    right = spin_array[i, (j+1) % L]
    delta_energy = 2 * spin * (J * (top + bottom + left + right) + h)
    return delta_energy

def monte_carlo_step():
    """Perform one Monte Carlo step per spin."""
    for _ in range(N):
        i, j = np.random.randint(0, L, size=2)
        spin = spin_array[i, j]
        dE = delta_E(i, j, spin)
        if dE < 0 or np.random.rand() < np.exp(-dE / (k_B * T)):
            spin_array[i, j] *= -1

def update_plot(frame):
    """Update the plot."""
    monte_carlo_step()
    img.set_array(spin_array)
    return img,

# Set up the plot
fig, ax = plt.subplots()
img = ax.imshow(spin_array, interpolation='none', vmin=-1, vmax=1)
ani = FuncAnimation(fig, update_plot, frames=200, interval=50, blit=True)

plt.show()

# Add a mechanism to change the magnetic field h dynamically if needed
def set_magnetic_field(new_h):
    global h
    h = new_h
