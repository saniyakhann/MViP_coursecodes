# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 14:08:09 2024

@author: s2147128
"""


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# System parameters
L = 50
J = -1
T = 1
k_B = 1
P = 25
tau = 10000
h0 = 10
N = L * L

# Initialize the lattice
np.random.seed(42)
spin_array = np.random.choice([-1, 1], size=(L, L))

# Function to compute the time-varying, space-dependent magnetic field
def h_field(x, y, n):
    return h0 * np.cos(2 * np.pi * x / P) * np.cos(2 * np.pi * y / P) * np.sin(2 * np.pi * n / tau)

# Calculate delta energy for spin flip at (i, j)
def delta_E(i, j, n):
    """Calculate the energy change if the spin at (i, j) is flipped."""
    spin = spin_array[i, j]
    top = spin_array[(i - 1) % L, j]
    bottom = spin_array[(i + 1) % L, j]
    left = spin_array[i, (j - 1) % L]
    right = spin_array[i, (j + 1) % L]
    h = h_field(i, j, n)
    delta_energy = 2 * spin * (J * (top + bottom + left + right) + h)
    return delta_energy

# Perform one Monte Carlo sweep
def monte_carlo_sweep(n):
    for _ in range(N):
        i, j = np.random.randint(0, L, size=2)
        dE = delta_E(i, j, n)
        if dE < 0 or np.random.rand() < np.exp(-dE / (k_B * T)):
            spin_array[i, j] *= -1

# Animation update function
def update_plot(frame):
    monte_carlo_sweep(frame)
    img.set_array(spin_array)
    ax.set_title(f'Time step: {frame} | Field factor: {np.sin(2 * np.pi * frame / tau):.2f}')
    return img,

# Set up the plot
fig, ax = plt.subplots()
img = ax.imshow(spin_array, interpolation='none', vmin=-1, vmax=1)
ani = FuncAnimation(fig, update_plot, frames=np.linspace(0, tau, 300, dtype=int), interval=50, blit=True)

plt.show()


#description of the Expected Spin Patterns:
#(i) When sin(2𝜋𝑛𝜏)≈−1sin( τ2πn )≈−1: The magnetic field is strong and negative across the lattice according to the spatial cosine pattern. The spins will tend to align opposite to their local field regions, creating a complex pattern reflecting the spatial cosine variation.
#(ii) When sin(2𝜋𝑛𝜏)≈0sin( τ2πn )≈0: The magnetic field effect is minimal, and the system's configuration may reflect the underlying antiferromagnetic interactions more strongly, resembling a checkerboard pattern in regions not perturbed by residual fields.
#(iii) When sin(2𝜋𝑛𝜏)≈1sin( τ2πn)≈1: The magnetic field is strong and positive. Spins will align with the field following the spatial cosine pattern, leading to a spatially varying alignment.