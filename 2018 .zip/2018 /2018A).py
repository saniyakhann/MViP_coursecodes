# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 22:23:22 2024

@author: s2147128
"""
#fisher equation 1DE example 2018 paper 


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# User input for parameters
N = int(input("Enter grid size N: "))          # Grid size
R = int(input("Enter droplet radius R: "))     # Radius of initial condition

D = 1            # Diffusion coefficient
alpha = 1        # Reaction rate
dt = 0.1         # Time step
dx = 1           # Spatial discretization

# Initialize the grid
phi = np.zeros((N, N))
center = N // 2
for i in range(N):
    for j in range(N):
        if np.sqrt((i - center)**2 + (j - center)**2) < R:
            phi[i, j] = 1.0

# Set up the plot
fig, ax = plt.subplots()
img = ax.imshow(phi, cmap='viridis', vmin=0, vmax=1)
plt.colorbar(img)

def update(frame):
    global phi
    new_phi = phi.copy()
    for i in range(N):
        for j in range(N):
            # Periodic boundary conditions
            up = phi[i-1, j] if i > 0 else phi[N-1, j]
            down = phi[i+1, j] if i < N-1 else phi[0, j]
            left = phi[i, j-1] if j > 0 else phi[i, N-1]
            right = phi[i, j+1] if j < N-1 else phi[i, 0]
            
            laplacian = up + down + left + right - 4*phi[i, j]
            new_phi[i, j] = phi[i, j] + dt * (D * laplacian + alpha * phi[i, j] * (1 - phi[i, j]))
    
    phi = new_phi
    img.set_data(phi)
    return img,

# Create animation
ani = FuncAnimation(fig, update, frames=100, interval=50)
plt.show()
