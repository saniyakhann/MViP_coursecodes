# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 15:39:16 2024

@author: s2147128
"""
#2020 SIR question a)

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def initialize_lattice(L):
    # Initialize the lattice with random states (0 for inactive, 1 for active)
    return np.random.choice([0, 1], size=(L, L), p=[0.5, 0.5])

def update(frameNum, img, lattice, L, p):
    # Perform L*L updates per sweep
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:  # If the cell is active
            if np.random.random() > p:
                lattice[x, y] = 0  # The cell becomes inactive
            else:
                # Choose one of the four neighbors randomly
                # Using periodic boundary conditions
                neighbors = [(x-1) % L, (x+1) % L, (y-1) % L, (y+1) % L]
                if np.random.random() < 0.5:
                    if np.random.random() < 0.5:
                        neighbor_x = neighbors[0]
                    else:
                        neighbor_x = neighbors[1]
                    neighbor_y = y
                else:
                    if np.random.random() < 0.5:
                        neighbor_y = neighbors[2]
                    else:
                        neighbor_y = neighbors[3]
                    neighbor_x = x
                
                if lattice[neighbor_x, neighbor_y] == 0:
                    lattice[neighbor_x, neighbor_y] = 1  # Infect the neighbor
    
    img.set_data(lattice)
    return img,

def simulation(p, L=50):
    # Setup the lattice and figure
    lattice = initialize_lattice(L)
    fig, ax = plt.subplots()
    img = ax.imshow(lattice, interpolation='nearest', cmap='viridis')
    ani = animation.FuncAnimation(fig, update, fargs=(img, lattice, L, p),
                                  frames=10, interval=50, save_count=50)
    plt.show()

# Example usage
simulation(p=0.5)
