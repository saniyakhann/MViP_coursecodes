# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:35:55 2024

@author: s2147128
"""

import numpy as np
import matplotlib.pyplot as plt

def initialize_lattice(L):
    return np.random.choice([0, 1], size=(L, L), p=[0.5, 0.5])

def update_lattice(lattice, L, p):
    new_lattice = np.copy(lattice)
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:
            if np.random.random() > p:
                new_lattice[x, y] = 0
            else:
                directions = [((x-1) % L, y), ((x+1) % L, y), (x, (y-1) % L), (x, (y+1) % L)]
                nx, ny = directions[np.random.randint(4)]
                new_lattice[nx, ny] = 1
    return new_lattice

def compute_average_fraction(p_values, L=50, sweeps=200, configurations=10):
    average_fractions = []
    for p in p_values:
        fractions = []
        for _ in range(configurations):
            lattice = initialize_lattice(L)
            for sweep in range(sweeps):
                lattice = update_lattice(lattice, L, p)
            fractions.append(np.mean(lattice))
        average_fractions.append(np.mean(fractions))
    return average_fractions

def plot_average_fraction():
    p_values = np.arange(0.55, 0.701, 0.005)
    average_fractions = compute_average_fraction(p_values)
    
    plt.plot(p_values, average_fractions)
    plt.title('Average Fraction of Active Sites vs. p')
    plt.xlabel('p')
    plt.ylabel('Average Fraction of Active Sites')
    plt.grid(True)
    plt.show()

plot_average_fraction()
