# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:46:10 2024

@author: s2147128
"""
import numpy as np
import matplotlib.pyplot as plt

def initialize_lattice_single_active(L):
    lattice = np.zeros((L, L))
    x, y = np.random.randint(L), np.random.randint(L)
    lattice[x, y] = 1  # Place a single active cell at a random position
    return lattice

def update_lattice(lattice, L, p):
    new_lattice = np.copy(lattice)
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:
            if np.random.random() > p:
                new_lattice[x, y] = 0
            else:
                directions = [((x-1) % L, y), ((x+1) % L, y), (x, (y-1) % L), (x, (y+1) % L)]
                nx, ny = directions[np.random.randint(4)]
                new_lattice[nx, ny] = 1
    return new_lattice

def compute_survival_probability(p, L=50, sweeps=300, simulations=100):
    survival_probabilities = np.zeros(sweeps+1)
    for _ in range(simulations):
        lattice = initialize_lattice_single_active(L)
        active_sites = [np.sum(lattice)]
        for sweep in range(sweeps):
            lattice = update_lattice(lattice, L, p)
            active_sites.append(np.sum(lattice))
        for i, active in enumerate(active_sites):
            if active > 0:
                survival_probabilities[i:] += 1
                break
    survival_probabilities /= simulations
    return survival_probabilities

def plot_survival_probability():
    p_values = [0.6, 0.625, 0.65]
    sweeps = 300
    
    plt.figure(figsize=(10, 6))
    for p in p_values:
        survival_probabilities = compute_survival_probability(p, sweeps=sweeps)
        plt.loglog(np.arange(sweeps+1), survival_probabilities, label=f'p = {p}')
    
    plt.title('Survival Probability vs. Time (log-log)')
    plt.xlabel('Time (Sweeps)')
    plt.ylabel('Survival Probability')
    plt.legend()
    plt.grid(True)
    plt.show()

plot_survival_probability()


#Explanation of the Modifications:

#Multiple p Values: The code now accepts a list of p values to compute the survival probability for each one.
#Extended Simulation: The simulation now runs for up tO t=300 sweeps.
#Plotting Function: The survival probabilities are plotted on a log-log scale to observe any power-law behavior.