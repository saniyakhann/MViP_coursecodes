# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:17:54 2024

@author: s2147128
"""



import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def initialize_lattice(L):
    return np.random.choice([0, 1], size=(L, L), p=[0.5, 0.5])

def update_lattice(lattice, L, p):
    # Copy lattice to avoid in-place modifications during the loop
    new_lattice = np.copy(lattice)
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:
            if np.random.random() > p:
                new_lattice[x, y] = 0
            else:
                # Periodic boundary conditions
                directions = [((x-1) % L, y), ((x+1) % L, y), (x, (y-1) % L), (x, (y+1) % L)]
                nx, ny = directions[np.random.randint(4)]
                new_lattice[nx, ny] = 1
    return new_lattice

def run_simulation(p, L=50, sweeps=200):
    lattice = initialize_lattice(L)
    infected_fraction = []
    
    for sweep in range(sweeps):
        lattice = update_lattice(lattice, L, p)
        fraction_infected = np.mean(lattice)
        infected_fraction.append(fraction_infected)
    
    return infected_fraction

def plot_infected_fractions():
    p_values = [0.6, 0.7]
    plt.figure(figsize=(10, 5))
    
    for p in p_values:
        infected_fraction = run_simulation(p, L=50, sweeps=200)
        plt.plot(infected_fraction, label=f'p = {p}')
    
    plt.title('Fraction of Infected Sites Over Time')
    plt.xlabel('Sweep Number')
    plt.ylabel('Fraction Infected')
    plt.legend()
    plt.grid(True)
    plt.show()

plot_infected_fractions()


#Explanation of Different Phases

#Subcritical Phase (p=0.6): At this probability, the 
#infection rate may not be sufficient to offset the recovery rate, 
#leading to eventual eradication of the infection. 
#This phase is characterized by the inability of the disease to sustain
#an epidemic, and the plot would typically show a decay in the fraction
#of infected sites to zero, indicative of disease extinction.

#Supercritical Phase (p=0.7): Here, the higher probability of infection suggests
#that the disease can not only maintain itself but potentially 
#spread further. The system is likely above the critical threshold 
#where the number of new infections on average exceeds the recoveries. 
#The plot for this scenario would stabilize at a nonzero fraction 
#of infected sites, reflecting an endemic state where 
#the infection persists indefinitely.