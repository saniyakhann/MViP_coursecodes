# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:36:41 2024

@author: s2147128
"""
import numpy as np
import matplotlib.pyplot as plt

def initialize_lattice(L):
    return np.random.choice([0, 1], size=(L, L), p=[0.5, 0.5])

def update_lattice(lattice, L, p):
    new_lattice = np.copy(lattice)
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:
            if np.random.random() > p:
                new_lattice[x, y] = 0
            else:
                directions = [((x-1) % L, y), ((x+1) % L, y), (x, (y-1) % L), (x, (y+1) % L)]
                nx, ny = directions[np.random.randint(4)]
                new_lattice[nx, ny] = 1
    return new_lattice

def compute_statistics(p_values, L=50, sweeps=200, configurations=10):
    average_fractions = []
    deltas = []
    for p in p_values:
        fractions = []
        squares = []  # To store A^2
        for _ in range(configurations):
            lattice = initialize_lattice(L)
            for sweep in range(sweeps):
                lattice = update_lattice(lattice, L, p)
            fraction = np.mean(lattice)
            fractions.append(fraction)
            squares.append(np.mean(lattice ** 2))
        average_fractions.append(np.mean(fractions))
        average_square = np.mean(squares)
        average_A_square = np.mean(np.array(fractions) ** 2)
        delta = average_A_square - average_square / (L ** 2)
        deltas.append(delta)
    return average_fractions, deltas

def plot_statistics():
    p_values = np.arange(0.55, 0.701, 0.005)
    average_fractions, deltas = compute_statistics(p_values)
    
    plt.errorbar(p_values, deltas, yerr=np.std(deltas), label='Δ', fmt='-o')
    plt.errorbar(p_values, average_fractions, yerr=np.std(average_fractions), label='f', fmt='-o')
    
    plt.title('Average Fraction of Active Sites and Δ vs. p')
    plt.xlabel('p')
    plt.ylabel('Value')
    plt.legend()
    plt.grid(True)
    plt.show()

plot_statistics()

#Discussion:

#Phase Transition: The phase transition occurs where Δ sharply changes behavior. 
#This corresponds to the point where the system transitions from a regime where fluctuations dominate to one where they are suppressed. 
#In the plot, this is where Δ changes from having relatively high fluctuations to low fluctuations. 
#It signifies a shift in the system's behavior, often indicating a change in phase.


#Comparing with Part c: In conjunction with the plot from part c, we can see how Δ behaves in relation to the average fraction of active sites. 
#At the phase transition point, the average fraction of active sites might exhibit a sudden change or be
#Δ might show a sharp peak or trough. This behavior is indicative of the 
#system's critical behavior, marking the transition between different phases. 
#By examining the plot of Δ, along with the average fraction of active sites, 
#we can identify the point of phase transition and understand the system's behavior in different phases

