# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 16:41:36 2024

@author: s2147128
"""
import numpy as np
import matplotlib.pyplot as plt

def initialize_lattice_single_active(L):
    lattice = np.zeros((L, L))
    x, y = np.random.randint(L), np.random.randint(L)
    lattice[x, y] = 1  # Place a single active cell at a random position
    return lattice

def update_lattice(lattice, L, p):
    new_lattice = np.copy(lattice)
    for _ in range(L*L):
        x, y = np.random.randint(L), np.random.randint(L)
        if lattice[x, y] == 1:
            if np.random.random() > p:
                new_lattice[x, y] = 0
            else:
                directions = [((x-1) % L, y), ((x+1) % L, y), (x, (y-1) % L), (x, (y+1) % L)]
                nx, ny = directions[np.random.randint(4)]
                new_lattice[nx, ny] = 1
    return new_lattice

def compute_survival_probability(L=50, p=0.6, sweeps=200, simulations=100):
    survival_probabilities = np.zeros(sweeps+1)
    for _ in range(simulations):
        lattice = initialize_lattice_single_active(L)
        active_sites = [np.sum(lattice)]
        for sweep in range(sweeps):
            lattice = update_lattice(lattice, L, p)
            active_sites.append(np.sum(lattice))
        for i, active in enumerate(active_sites):
            if active > 0:
                survival_probabilities[i:] += 1
                break
    survival_probabilities /= simulations
    return survival_probabilities

def plot_survival_probability():
    sweeps = 200
    survival_probabilities = compute_survival_probability(sweeps=sweeps)
    
    plt.plot(np.arange(sweeps+1), survival_probabilities, marker='o')
    plt.title('Survival Probability vs. Time')
    plt.xlabel('Time (Sweeps)')
    plt.ylabel('Survival Probability')
    plt.grid(True)
    plt.show()

plot_survival_probability()


#Explanation of the Modifications:

#Single Active Cell Initialization: The lattice is initialized with all cells being inactive, except for a single randomly chosen cell that is set to active.
#Compute Survival Probability Function: This function runs multiple simulations, each starting with a single active cell, and counts how many simulations have active sites left at each time step. It calculates the survival probability as the fraction of simulations with active sites remaining at each time step.
#Plotting Function: This function plots the survival probability versus time, where time is measured in sweeps.