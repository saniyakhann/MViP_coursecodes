# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 13:55:12 2024

@author: s2147128

"""

#2016 paper ISING MODEL example animation code 

import numpy as np
import matplotlib.pyplot as plt

# System parameters
L = 50
N = L**2
J = -1
T = 1
k_B = 1
h_values = np.arange(0, 10.5, 0.5)
equilibration_steps = 1000
measurement_steps = 5000

# Helper function to compute staggered sign
def staggered_sign(i, j):
    return (-1)**(i + j)

# Initialize the lattice
np.random.seed(42)
spin_array = np.random.choice([-1, 1], size=(L, L))

# Calculate delta energy for spin flip at (i, j)
def delta_E(i, j):
    """Calculate the energy change if the spin at (i, j) is flipped."""
    spin = spin_array[i, j]
    top = spin_array[(i - 1) % L, j]
    bottom = spin_array[(i + 1) % L, j]
    left = spin_array[i, (j - 1) % L]
    right = spin_array[i, (j + 1) % L]
    delta_energy = 2 * spin * (J * (top + bottom + left + right) + h)
    return delta_energy

# Perform one Monte Carlo step per spin
def monte_carlo_step():
    for _ in range(N):
        i, j = np.random.randint(0, L, size=2)
        dE = delta_E(i, j)
        if dE < 0 or np.random.rand() < np.exp(-dE / (k_B * T)):
            spin_array[i, j] *= -1

# Main data collection function
def collect_data():
    m_values = []
    ms_values = []
    energies = []
    for step in range(measurement_steps):
        monte_carlo_step()
        m = np.sum(spin_array)
        ms = np.sum(staggered_sign(i, j) * spin_array[i, j] for i in range(L) for j in range(L))
        energy = -J * np.sum(spin_array * (np.roll(spin_array, 1, axis=0) + np.roll(spin_array, 1, axis=1))) - h * np.sum(spin_array)
        m_values.append(m)
        ms_values.append(ms)
        energies.append(energy)
    return np.mean(m_values), np.var(m_values), np.mean(ms_values), np.var(ms_values), np.mean(energies)

# Run simulation and collect results
mean_m = []
var_m = []
mean_ms = []
var_ms = []
mean_e = []

for h in h_values:
    # Equilibrate system
    for _ in range(equilibration_steps):
        monte_carlo_step()
    results = collect_data()
    mean_m.append(results[0] / N)
    var_m.append(results[1] / N**2)
    mean_ms.append(results[2] / N)
    var_ms.append(results[3] / N**2)
    mean_e.append(results[4] / N)

# Plotting results
plt.figure(figsize=(12, 8))
plt.subplot(311)
plt.plot(h_values, mean_m, label='Mean M')
plt.plot(h_values, var_m, label='Variance of M')
plt.title('Magnetization')
plt.xlabel('Magnetic field h')
plt.ylabel('Magnetization')
plt.legend()

plt.subplot(312)
plt.plot(h_values, mean_ms, label='Mean Ms')
plt.plot(h_values, var_ms, label='Variance of Ms')
plt.title('Staggered Magnetization')
plt.xlabel('Magnetic field h')
plt.ylabel('Staggered Magnetization')
plt.legend()

plt.subplot(313)
plt.plot(h_values, mean_e, label='Mean Energy')
plt.title('Energy')
plt.xlabel('Magnetic field h')
plt.ylabel('Energy')
plt.legend()

plt.tight_layout()
plt.show()
