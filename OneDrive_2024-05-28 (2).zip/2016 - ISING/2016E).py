# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 14:35:15 2024

@author: s2147128
"""
import numpy as np
import matplotlib.pyplot as plt

def run_simulation(P, tau=10000, h0=10, L=50, J=-1, T=1, total_steps=300):
    N = L**2
    k_B = 1
    np.random.seed(42)
    spin_array = np.random.choice([-1, 1], size=(L, L))
    
    # Compute staggered sign matrix
    staggered_sign = np.array([[((-1)**(i+j)) for j in range(L)] for i in range(L)])
    
    # Function for staggered magnetization
    def get_staggered_magnetization():
        return np.sum(staggered_sign * spin_array)
    
    # Function to compute field at a point
    def h_field(n):
        return h0 * np.sin(2 * np.pi * n / tau)
    
    # Function to compute energy change for a spin flip
    def delta_E(i, j, n):
        spin = spin_array[i, j]
        top = spin_array[(i - 1) % L, j]
        bottom = spin_array[(i + 1) % L, j]
        left = spin_array[i, (j - 1) % L]
        right = spin_array[i, (j + 1) % L]
        h = h0 * np.cos(2 * np.pi * i / P) * np.cos(2 * np.pi * j / P) * np.sin(2 * np.pi * n / tau)
        return 2 * spin * (J * (top + bottom + left + right) + h)
    
    # Collect data
    time_steps = np.linspace(0, tau, total_steps, dtype=int)
    h_values = []
    ms_values = []
    
    for n in time_steps:
        for _ in range(N):
            i, j = np.random.randint(0, L, size=2)
            dE = delta_E(i, j, n)
            if dE < 0 or np.random.rand() < np.exp(-dE / (k_B * T)):
                spin_array[i, j] *= -1
        h_values.append(h_field(n))
        ms_values.append(get_staggered_magnetization())
    
    # Save results to file
    with open(f"staggered_mag_P{P}.txt", "w") as f:
        for h, ms in zip(h_values, ms_values):
            f.write(f"{h} {ms}\n")
    
    return time_steps, h_values, ms_values

# Run simulation for two spatial periods
results_25 = run_simulation(P=25)
results_10 = run_simulation(P=10)

# Plot results
fig, axes = plt.subplots(2, 1, figsize=(10, 8))

for ax, results, P in zip(axes, [results_25, results_10], [25, 10]):
    time_steps, h_values, ms_values = results
    ax.plot(time_steps, ms_values, label=f"Staggered Mag, P={P}")
    ax.set_title(f"Staggered Magnetization over Time, P={P}")
    ax.set_xlabel("Time (MC Sweeps)")
    ax.set_ylabel("Staggered Magnetization")
    ax.legend


#Decreasing Spatial Period 𝑃: 
    #As 𝑃 decreases, the magnetic field oscillates more rapidly across the lattice.
    #This can lead to more frequent changes in local field alignments 
    #and potentially more complex interactions between spins, 
    #influencing the stability and visibility of the staggered magnetization pattern.
    #This might also lead to less clearly defined antiferromagnetic domains, 
    #especially when the field oscillates significantly within a single Monte Carlo 
    #sweep duration.